// SHADOW X PANEL - Firebase browser module starter.
// Replace the firebaseConfig values and ADMIN_UID before running.
import { initializeApp } from "https://www.gstatic.com/firebasejs/13.2.0/firebase-app.js";
import {
  getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/13.2.0/firebase-auth.js";
import {
  getFirestore, collection, addDoc, updateDoc, deleteDoc, doc,
  onSnapshot, query, orderBy, serverTimestamp
} from "https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID",
  appId: "PASTE_APP_ID"
};

// Paste the UID of the admin account created in Firebase Authentication.
const ADMIN_UID = "PASTE_ADMIN_USER_UID";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const playersRef = collection(db, "players");

const $ = (id) => document.getElementById(id);
let unsubscribePlayers = null;
let allPlayers = [];
let activity = [];

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  window.setTimeout(() => el.classList.remove("show"), 2800);
}

function recordActivity(message) {
  activity.unshift({ message, time: new Date().toLocaleTimeString() });
  activity = activity.slice(0, 40);
  renderActivity();
}

function renderActivity() {
  const target = $("activityList");
  if (!activity.length) {
    target.innerHTML = '<p class="muted">No activity yet.</p>';
    return;
  }
  target.replaceChildren();
  activity.forEach(item => {
    const row = document.createElement("div");
    row.className = "activity-item";
    const msg = document.createElement("b");
    msg.textContent = item.message;
    const time = document.createElement("span");
    time.textContent = item.time;
    row.append(msg, time);
    target.append(row);
  });
}

function setPage(name) {
  document.querySelectorAll(".page").forEach(page => page.classList.add("hidden"));
  const page = $(name + "Page");
  if (page) page.classList.remove("hidden");
  document.querySelectorAll(".nav-link[data-page]").forEach(button => {
    button.classList.toggle("active", button.dataset.page === name);
  });
  $("pageName").textContent = name.toUpperCase();
  $("sidebar").classList.remove("open");
}

function showLogin(message = "") {
  $("loginScreen").classList.remove("hidden");
  $("appShell").classList.add("hidden");
  $("loginMessage").textContent = message;
}

function showApp(user) {
  $("loginScreen").classList.add("hidden");
  $("appShell").classList.remove("hidden");
  $("adminEmail").textContent = user.email || "Admin";
  $("todayLabel").textContent = new Date().toLocaleDateString(undefined, {
    weekday: "short", month: "short", day: "numeric", year: "numeric"
  }).toUpperCase();
  setPage("overview");
  listenForPlayers();
}

function stopListening() {
  if (unsubscribePlayers) unsubscribePlayers();
  unsubscribePlayers = null;
}

function listenForPlayers() {
  stopListening();
  $("connectionState").textContent = "Connecting…";
  const q = query(playersRef, orderBy("createdAt", "desc"));
  unsubscribePlayers = onSnapshot(q, snapshot => {
    allPlayers = snapshot.docs.map(item => ({ id: item.id, ...item.data() }));
    $("connectionState").textContent = "Connected · live updates";
    renderPlayers();
    renderStats();
  }, error => {
    console.error(error);
    $("connectionState").textContent = "Database error";
    toast("Could not read player records. Check Firestore rules.");
  });
}

function renderStats() {
  const active = allPlayers.filter(player => player.status === "Active").length;
  $("totalPlayers").textContent = allPlayers.length;
  $("activePlayers").textContent = active;
  $("inactivePlayers").textContent = allPlayers.length - active;
}

function makeStatus(status) {
  const badge = document.createElement("span");
  badge.className = "status" + (status === "Active" ? "" : " inactive");
  badge.textContent = status || "Unknown";
  return badge;
}

function buildTable(players, includeActions) {
  const wrap = document.createElement("div");
  wrap.className = "table-wrap";
  const table = document.createElement("table");
  table.className = "data-table";
  const thead = document.createElement("thead");
  const headRow = document.createElement("tr");
  ["PLAYER", "GAME / TEAM", "STATUS", ...(includeActions ? ["ACTIONS"] : [])].forEach(label => {
    const th = document.createElement("th");
    th.textContent = label;
    headRow.append(th);
  });
  thead.append(headRow);
  const tbody = document.createElement("tbody");

  players.forEach(player => {
    const row = document.createElement("tr");
    const name = document.createElement("td");
    name.className = "player-name";
    name.textContent = player.name || "Unnamed";
    const game = document.createElement("td");
    game.className = "sub-cell";
    game.textContent = player.game || "—";
    const status = document.createElement("td");
    status.append(makeStatus(player.status));
    row.append(name, game, status);

    if (includeActions) {
      const actions = document.createElement("td");
      const group = document.createElement("div");
      group.className = "table-actions";
      const edit = document.createElement("button");
      edit.className = "mini-btn";
      edit.textContent = "Edit";
      edit.addEventListener("click", () => beginEdit(player));
      const remove = document.createElement("button");
      remove.className = "mini-btn delete";
      remove.textContent = "Delete";
      remove.addEventListener("click", () => removePlayer(player));
      group.append(edit, remove);
      actions.append(group);
      row.append(actions);
    }
    tbody.append(row);
  });

  table.append(thead, tbody);
  wrap.append(table);
  if (!players.length) {
    const empty = document.createElement("p");
    empty.className = "muted empty";
    empty.textContent = "No player records yet. Add your first player above.";
    wrap.append(empty);
  }
  return wrap;
}

function renderPlayers() {
  const term = $("searchPlayers").value.trim().toLowerCase();
  const filtered = allPlayers.filter(player =>
    (player.name || "").toLowerCase().includes(term) ||
    (player.game || "").toLowerCase().includes(term) ||
    (player.status || "").toLowerCase().includes(term)
  );
  $("playersTable").replaceChildren(buildTable(filtered, true));
  $("playerCountTag").textContent = allPlayers.length;
  $("recentPlayers").replaceChildren(buildTable(allPlayers.slice(0, 5), false));
}

function beginEdit(player) {
  $("playerId").value = player.id;
  $("playerName").value = player.name || "";
  $("playerGame").value = player.game || "";
  $("playerStatus").value = player.status || "Active";
  $("formTitle").textContent = "Edit player";
  $("savePlayerBtn").textContent = "Save changes";
  $("cancelEditBtn").classList.remove("hidden");
  $("playerName").focus();
  setPage("players");
}

function resetPlayerForm() {
  $("playerForm").reset();
  $("playerId").value = "";
  $("formTitle").textContent = "Add a player";
  $("savePlayerBtn").textContent = "＋ Save player";
  $("cancelEditBtn").classList.add("hidden");
}

async function removePlayer(player) {
  if (!window.confirm(`Delete ${player.name || "this player"}? This cannot be undone.`)) return;
  try {
    await deleteDoc(doc(db, "players", player.id));
    recordActivity("Deleted player: " + (player.name || player.id));
    toast("Player deleted.");
  } catch (error) {
    console.error(error);
    toast("Delete failed. Check your Firestore rules.");
  }
}

$("loginForm").addEventListener("submit", async event => {
  event.preventDefault();
  $("loginMessage").textContent = "Signing in…";
  try {
    await signInWithEmailAndPassword(auth, $("email").value.trim(), $("password").value);
  } catch (error) {
    console.error(error);
    $("loginMessage").textContent = "Sign-in failed. Check your email and password.";
  }
});

$("logoutBtn").addEventListener("click", async () => {
  stopListening();
  await signOut(auth);
  recordActivity("Admin signed out");
});

onAuthStateChanged(auth, user => {
  if (!user) {
    stopListening();
    showLogin();
    return;
  }
  if (user.uid !== ADMIN_UID) {
    signOut(auth);
    showLogin("This account is not authorized as the panel administrator.");
    return;
  }
  showApp(user);
  recordActivity("Admin signed in");
});

$("playerForm").addEventListener("submit", async event => {
  event.preventDefault();
  const name = $("playerName").value.trim();
  const game = $("playerGame").value.trim();
  const status = $("playerStatus").value;
  const id = $("playerId").value;
  if (!name) return toast("Player name is required.");

  const payload = {
    name,
    game,
    status,
    updatedAt: serverTimestamp()
  };

  try {
    if (id) {
      await updateDoc(doc(db, "players", id), payload);
      recordActivity("Updated player: " + name);
      toast("Player updated.");
    } else {
      await addDoc(playersRef, { ...payload, createdAt: serverTimestamp() });
      recordActivity("Added player: " + name);
      toast("Player added.");
    }
    resetPlayerForm();
  } catch (error) {
    console.error(error);
    toast("Save failed. Check your Firestore rules and configuration.");
  }
});

$("cancelEditBtn").addEventListener("click", resetPlayerForm);
$("searchPlayers").addEventListener("input", renderPlayers);
document.querySelectorAll(".nav-link[data-page]").forEach(button => {
  button.addEventListener("click", () => setPage(button.dataset.page));
});
document.querySelectorAll("[data-goto]").forEach(button => {
  button.addEventListener("click", () => setPage(button.dataset.goto));
});
$("menuBtn").addEventListener("click", () => $("sidebar").classList.toggle("open"));
